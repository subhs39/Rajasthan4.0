<!DOCTYPE html">
<html><head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>La Carte - Projection</title>
<style type="text/css">
html, body
{
   height: 100%;
}
div#space
{
   width: 1px;
   height: 50%;
   margin-bottom: -240px;
   float:left
}
div#container
{
   width: 640px;
   height: 480px;
   margin: 0 auto;
   position: relative;
   clear: left;
}
</style>
<style type="text/css">
body
{
   margin: 0;
   padding: 0;
   background-color: #000000;
   color: #000000;
}
</style>
<style type="text/css">
a:hover
{
   color: #949693;
}
</style>
<script type="text/javascript" src="La%20Carte%20-%20Projection_files/jquery-1.js"></script>
<script type="text/javascript">
<!--
function ShowObject(id, flag)
{
   var elem=document.getElementById(id);
   if(elem)
      elem.style.visibility=flag?'visible':'hidden';
}
function MoveObject(id, left, top)
{
   var elem=document.getElementById(id);
   if(elem)
   {
      elem.style.left=left+'px';
      elem.style.top=top+'px';
   }
}
function Animate(id, left, top, width, height, opacity, duration)
{
   var selector = '#' + id;
   var attributes = new Object();
   if (left != "")
   {
      attributes.left = left;
   }
   if (top != "")
   {
      attributes.top = top;
   }
   if (width != "")
   {
      attributes.width = width;
   }
   if (height != "")
   {
      attributes.height = height;
   }
   if (opacity != "")
   {
      attributes.opacity = opacity/100;
   }
   if (id.indexOf('bv_') == 0)
   {
      var sel = '#' + id.substring(3);
      $(sel).stop().animate(attributes, duration);
   }
   $(selector).stop().animate(attributes, duration);
}
</script>
</head>
<body onload="ShowObject('bv_Image1', 1);ShowObject('bv_Image2', 1);ShowObject('bv_Image3', 0);MoveObject('bv_Image2',229,270);MoveObject('bv_Image1',211,20);ShowObject('bv_Image4', 0);ShowObject('bv_Image5', 0);ShowObject('bv_Image10', 0);ShowObject('bv_Image9', 0);ShowObject('bv_Image6', 0);ShowObject('bv_Image7', 0);ShowObject('bv_Image8', 0);ShowObject('bv_Image11', 0);ShowObject('bv_Image12', 0);ShowObject('bv_Image13', 0);ShowObject('bv_Image14', 0);ShowObject('bv_Image15', 0);ShowObject('bv_Image16', 0);ShowObject('bv_Image17', 0);ShowObject('bv_Image18', 0);ShowObject('bv_Image19', 0);ShowObject('bv_Image20', 0);ShowObject('bv_Image21', 0);ShowObject('finalbill',0);ShowObject('confirm',0);MoveObject('confirm', 120, 120);ShowObject('infobox',0);return false;">
<div id="space"><br></div>
<div id="container">
<div id="bv_Shape1" style="margin:0;padding:0;position:absolute;left:0px;top:0px;width:640px;height:480px;text-align:center;z-index:0;">
<img src="La%20Carte%20-%20Projection_files/01141.gif" id="Shape1" alt="" title="" style="border-width:0;width:640px;height:480px"></div>
<div id="bv_Image1" style="margin: 0px; padding: 0px; position: absolute; left: 211px; top: 250px; width: 204px; height: 193px; text-align: left; z-index: 1; visibility: hidden;">
<a href="#" onclick="ShowObject('bv_Image2', 0);ShowObject('bv_Image3', 0);Animate('bv_Image1', '211', '250', '', '', '', 500);ShowObject('bv_Image4', 1);ShowObject('bv_Image5', 1);MoveObject('bv_Image4',23,80);MoveObject('bv_Image5',431,80);return false;"><img src="La%20Carte%20-%20Projection_files/order.png" id="Image1" alt="" style="width: 204px; height: 193px; left: 211px; top: 250px;" border="0" align="top"></a></div>
<div id="bv_Image2" style="margin: 0px; padding: 0px; position: absolute; left: 229px; top: 270px; width: 153px; height: 140px; text-align: left; z-index: 2; visibility: hidden;">
<a href="#" onclick="ShowObject('bv_Image3', 1);ShowObject('bv_Image2', 0);MoveObject('bv_Image3',526,373);return false;"><img src="La%20Carte%20-%20Projection_files/clean.png" id="Image2" alt="" style="width:153px;height:140px;" border="0" align="top"></a></div>
<div id="bv_Image3" style="margin: 0px; padding: 0px; position: absolute; left: 526px; top: 373px; width: 109px; height: 102px; text-align: left; z-index: 3; visibility: hidden;">
<img src="La%20Carte%20-%20Projection_files/request.png" id="Image3" alt="" style="width:109px;height:102px;" border="0" align="top"></div>
<div id="bv_Image4" style="margin: 0px; padding: 0px; position: absolute; left: 243px; top: 0px; width: 166px; height: 156px; text-align: left; z-index: 4; visibility: hidden;">
<a href="#" onclick="ShowObject('bv_Image1', 0);ShowObject('bv_Image5', 0);Animate('bv_Image4', '243', '0', '', '', '', 500);ShowObject('bv_Image9', 1);ShowObject('bv_Image10', 1);MoveObject('bv_Image9',5,212);MoveObject('bv_Image10',448,222);return false;"><img src="La%20Carte%20-%20Projection_files/eng.png" id="Image4" alt="" style="width: 166px; height: 156px; left: 243px; top: 0px;" border="0" align="top"></a></div>
<div id="bv_Image5" style="margin: 0px; padding: 0px; position: absolute; left: 431px; top: 80px; width: 164px; height: 155px; text-align: left; z-index: 5; visibility: hidden;">
<a href="#" onclick="ShowObject('bv_Image4', 0);ShowObject('bv_Image1', 0);ShowObject('bv_Image14', 1);ShowObject('bv_Image15', 1);Animate('bv_Image5', '228', '0', '', '', '', 500);MoveObject('bv_Image14',0,245);MoveObject('bv_Image15',436,244);return false;"><img src="La%20Carte%20-%20Projection_files/hindi.png" id="Image5" alt="" style="width:164px;height:155px;" border="0" align="top"></a></div>
<form method="post" action="add.php">
      <div id="bv_Image6" style="margin: 0px; padding: 0px; position: absolute; left: 1038px; top: 263px; width: 125px; height: 117px; text-align: left; z-index: 6; visibility: hidden;">
      <input type="image" src="La%20Carte%20-%20Projection_files/veg1.png" id="Image6" alt="submit" style="width:125px;height:117px;" border="0" align="top"></div>
      <input type="hidden" name="food" value="Veg1"/>
</form>
<form method="post" action="add.php">
      <div id="bv_Image7" style="margin: 0px; padding: 0px; position: absolute; left: 1121px; top: 368px; width: 117px; height: 110px; text-align: left; z-index: 7; visibility: hidden;">
      <input type="image" src="La%20Carte%20-%20Projection_files/veg2.png" id="Image7" alt="submit" style="width:117px;height:110px;" border="0" align="top"></div>
      <input type="hidden" name="food" value="Veg2"/>
</form>
<form method="post" action="add.php">
      <div id="bv_Image8" style="margin: 0px; padding: 0px; position: absolute; left: 1016px; top: 398px; width: 117px; height: 111px; text-align: left; z-index: 8; visibility: hidden;">
      <input type="image" src="La%20Carte%20-%20Projection_files/veg3.png" id="Image8" alt="submit" style="width:117px;height:111px;" border="0" align="top"></div>
      <input type="hidden" name="food" value="Veg3"/>
</form>
<div id="bv_Image9" style="margin: 0px; padding: 0px; position: absolute; left: 5px; top: 212px; width: 182px; height: 171px; text-align: left; z-index: 9; visibility: hidden;">
<a href="#" onclick="Animate('bv_Image9', '222', '11', '', '', '', 500);ShowObject('bv_Image6', 1);ShowObject('bv_Image7', 1);ShowObject('bv_Image8', 1);ShowObject('bv_Image10', 0);MoveObject('bv_Image6',0,211);MoveObject('bv_Image7',256,319);MoveObject('bv_Image8',498,212);ShowObject('bv_Image4', 0);return false;"><img src="La%20Carte%20-%20Projection_files/veg.png" id="Image9" alt="" style="width:182px;height:171px;" border="0" align="top"></a></div>
<div id="bv_Image10" style="margin: 0px; padding: 0px; position: absolute; left: 223px; top: 0px; width: 176px; height: 163px; text-align: left; z-index: 10; visibility: visible;">
<a href="#" onclick="ShowObject('bv_Image11', 1);ShowObject('bv_Image12', 1);ShowObject('bv_Image13', 1);Animate('bv_Image10', '223', '0', '', '', '', 500);ShowObject('bv_Image9', 0);ShowObject('bv_Image4', 0);MoveObject('bv_Image11',0,184);MoveObject('bv_Image12',206,304);MoveObject('bv_Image13',460,200);return false;"><img src="La%20Carte%20-%20Projection_files/non-veg.png" id="Image10" alt="" style="width: 176px; height: 163px; left: 223px; top: 0px;" border="0" align="top"></a></div>
<form method="post" action="add.php">
      <div id="bv_Image11" style="margin: 0px; padding: 0px; position: absolute; left: 0px; top: 184px; width: 147px; height: 139px; text-align: left; z-index: 11; visibility: visible;">
      <input type="image" name="food" value="NonVeg1" src="La%20Carte%20-%20Projection_files/non-veg1.png" id="Image11" alt="submit" style="width:147px;height:139px;" border="0" align="top"></div>
      <input type="hidden" name="food" value="NonVeg1"/>
</form>
<form method="post" action="add.php">
      <div id="bv_Image12" style="margin: 0px; padding: 0px; position: absolute; left: 206px; top: 304px; width: 148px; height: 140px; text-align: left; z-index: 12; visibility: visible;">
      <input type="image" name="food" value="NonVeg2" src="La%20Carte%20-%20Projection_files/non-veg2.png" id="Image12" alt="submit" style="width:148px;height:140px;" border="0" align="top"></div>
      <input type="hidden" name="food" value="NonVeg2"/>
</form>    
<form method="post" action="add.php">  
      <div id="bv_Image13" style="margin: 0px; padding: 0px; position: absolute; left: 460px; top: 200px; width: 146px; height: 137px; text-align: left; z-index: 13; visibility: visible;">
      <input type="image" name="food" value="NonVeg3" src="La%20Carte%20-%20Projection_files/non-veg3.png" id="Image13" alt="submit" style="width:146px;height:137px;" border="0" align="top"></div>
      <input type="hidden" name="food" value="NonVeg3"/>
</form>      
      <div id="bv_Image14" style="margin: 0px; padding: 0px; position: absolute; left: 1077px; top: 433px; width: 187px; height: 174px; text-align: left; z-index: 14; visibility: hidden;">
<a href="#" onclick="Animate('bv_Image14', '220', '0', '', '', '', 500);ShowObject('bv_Image16', 1);ShowObject('bv_Image17', 1);ShowObject('bv_Image18', 1);MoveObject('bv_Image16',0,197);MoveObject('bv_Image17',237,312);MoveObject('bv_Image18',471,200);ShowObject('bv_Image5', 0);ShowObject('bv_Image15', 0);return false;"><img src="La%20Carte%20-%20Projection_files/Hveg.png" id="Image14" alt="" style="width:187px;height:174px;" border="0" align="top"></a></div>
<div id="bv_Image15" style="margin: 0px; padding: 0px; position: absolute; left: 235px; top: 0px; width: 193px; height: 180px; text-align: left; z-index: 15; visibility: hidden;">
<a href="#" onclick="ShowObject('bv_Image14', 0);ShowObject('bv_Image5', 0);ShowObject('bv_Image19', 1);ShowObject('bv_Image20', 1);ShowObject('bv_Image21', 1);Animate('bv_Image15', '236', '0', '', '', '', 500);MoveObject('bv_Image19',0,185);MoveObject('bv_Image20',239,329);return false;"><img src="La%20Carte%20-%20Projection_files/Hnon-veg.png" id="Image15" alt="" style="width:193px;height:180px;" border="0" align="top"></a></div>
<form method="post" action="add.php">
      <div id="bv_Image16" style="margin: 0px; padding: 0px; position: absolute; left: 1131px; top: 247px; width: 183px; height: 173px; text-align: left; z-index: 16; visibility: hidden;">
      <input type="image" name="food" value="Veg1" src="La%20Carte%20-%20Projection_files/Hnon-veg1.png" id="Image16" alt="" style="width:183px;height:173px;" border="0" align="top"></div>
      <input type="hidden" name="food" value="Veg1"/>
 </form>
 <form  method="post" action="add.php">
      <div id="bv_Image17" style="margin: 0px; padding: 0px; position: absolute; left: 1206px; top: 0px; width: 178px; height: 167px; text-align: left; z-index: 17; visibility: hidden;">
      <input type="image" name="food" value="Veg2" src="La%20Carte%20-%20Projection_files/Hnon-veg2.png" id="Image17" alt="" style="width:178px;height:167px;" border="0" align="top"></div>
      <input type="hidden" name="food" value="Veg2"/>
</form>
<form  method="post" action="add.php">      
      <div id="bv_Image18" style="margin: 0px; padding: 0px; position: absolute; left: 1227px; top: 151px; width: 169px; height: 159px; text-align: left; z-index: 18; visibility: hidden;">
      <input type="image" name="food" value="Veg3" src="La%20Carte%20-%20Projection_files/Hnon-veg3.png" id="Image18" alt="" style="width:169px;height:159px;" border="0" align="top"></div>
      <input type="hidden" name="food" value="Veg3"/>
</form>
<form method="post" action="add.php">
      <div id="bv_Image19" style="margin: 0px; padding: 0px; position: absolute; left: 0px; top: 185px; width: 172px; height: 163px; text-align: left; z-index: 19; visibility: hidden;">
      <input type="image" name="food" value="NonVeg1" src="La%20Carte%20-%20Projection_files/Hnon-veg1.png" id="Image19" alt="" style="width:172px;height:163px;" border="0" align="top"></div>
      <input type="hidden" name="food" value="NonVeg1"/>
</form>
<form method="post" action="add.php">      
      <div id="bv_Image20" style="margin: 0px; padding: 0px; position: absolute; left: 239px; top: 329px; width: 161px; height: 152px; text-align: left; z-index: 20; visibility: hidden;">
      <input type="image" name="food" value="NonVeg2" src="La%20Carte%20-%20Projection_files/Hnon-veg2.png" id="Image20" alt="" style="width:161px;height:152px;" border="0" align="top"></div>
      <input type="hidden" name="food" value="NonVeg2"/>
</form>
<form method="post" action="add.php">     
      <div id="bv_Image21" style="margin: 0px; padding: 0px; position: absolute; left: 479px; top: 190px; width: 171px; height: 161px; text-align: left; z-index: 21; visibility: hidden;">
      <input type="image" name="food" value="NonVeg3" src="La%20Carte%20-%20Projection_files/Hnon-veg3.png" id="Image21" alt="" style="width:171px;height:161px;" border="0" align="top"></div>
      <input type="hidden" name="food" value="NonVeg3"/>
</form>
</div>
<div style="position:absolute;padding:10px;top:74px;left:967px;background-color:white;color:black;border: 10px solid yellow;">
<center><h2 onclick="ShowObject('finalbill',1);">Order</h2></center>
<ul>
<?php 
      $conn = mysqli_connect("localhost","root","","lacarte");
      $sql = "select * from table1";

      $result = $conn->query($sql);
      while($row=$result->fetch_assoc()) {
            echo "<li>" . $row['OrderName'] . "</li>";
      }
?>
</ul>
</div>

<input type="image" src="PRO/confirmed.png" alt="submit" style="position:absolute;top:70px;left:855px;height:120px;width:120px;" onclick="ShowObject('bv_Image1',0);ShowObject('bv_Image2',0);ShowObject('bv_Image3',0);ShowObject('bv_Image4',0);ShowObject('bv_Image5',0);ShowObject('bv_Image6',0);ShowObject('bv_Image7',0);ShowObject('bv_Image8',0);ShowObject('bv_Image9',0);ShowObject('bv_Image10',0);ShowObject('bv_Image11',0);ShowObject('bv_Image12',0);ShowObject('bv_Image13',0);ShowObject('bv_Image14',0);ShowObject('bv_Image15',0);ShowObject('bv_Image16',0);ShowObject('infobox',1);"/>
<div id="infobox" style="position:absolute;top:270px;left:400px;background-color:white;border:5px solid yellow;width:500px;"/>
<h3>Your Order has been Placed.</h3>
</div>
</body>
</html>