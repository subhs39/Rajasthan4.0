<?php
    $conn = mysqli_connect("localhost","root","toor","lacarte");
    if($conn->connect_error) {
        echo "Error Connecting Database. Connection Error : " . $conn->connect_error;
    }

    $option = $_POST['food'];
    $price = 0.0;

    switch($option) {
        case 'Veg1' :       global $price;
                                $price = 10.6;
                                break;
        case 'Veg2' :       global $price;
                                $price = 19.8;
                                break;
        case 'Veg3' :       global $price;
                                $price = 14.5;
                                break;
        case 'NonVeg1' :    global $price;
                                $price = 30.6;
                                break;
        case 'NonVeg2' :    global $price;
                                $price = 31.5;
                                break;
        case 'NonVeg3' :    global $price;
                                $price = 52.3;
                                break;
    }

    $sql = "INSERT into table1 values (" . 625 . ",'" . $option . "'," . $price . ")";
    if ($conn->query($sql) === TRUE) {
        echo "<h2>New record created successfully</h2>";
        header("Location: ./");
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
?>